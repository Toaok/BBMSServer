CREATE TRIGGER t_beforeinsert_on_readerinfo
BEFORE INSERT ON readerinfo
FOR EACH ROW
  BEGIN
    #当读者类型是学生
    IF (NEW.reader_type = '学生')
    THEN
      BEGIN
        SET NEW.reader_debit_amount = 10;
        SET NEW.reader_time_limit = 45;
      END;
    #当读者类型是教师
    ELSEIF (NEW.reader_type = '教师')
      THEN
        BEGIN
          SET NEW.reader_debit_amount = 15;
          SET NEW.reader_time_limit = 60;
        END;
    END IF;
  END;
