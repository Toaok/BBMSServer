CREATE TRIGGER t_beforeupdate_on_readerinfo
BEFORE UPDATE ON readerinfo
FOR EACH ROW
  BEGIN
    IF (NEW.reader_sex != '男' && NEW.reader_sex != '女')
    THEN
      BEGIN
        SET NEW.reader_sex = '男';
      END;
    END IF;
    IF (NEW.reader_type != '学生' && NEW.reader_type != '教师')
    THEN
      BEGIN
        SET NEW.reader_type = '学生';
      END;
    END IF;
    #当读者类型是学生
    IF (NEW.reader_type = '学生')
    THEN
      BEGIN
        SET NEW.reader_debit_amount = 10;
        SET NEW.reader_time_limit = 45;
      END;
    #当读者类型是教师
    ELSEIF (NEW.reader_type = '教师')
      THEN
        BEGIN
          SET NEW.reader_debit_amount = 15;
          SET NEW.reader_time_limit = 60;
        END;
    END IF;
  END;
