CREATE TRIGGER t_afterinsert_on_account
AFTER INSERT ON account
FOR EACH ROW
  BEGIN
    INSERT INTO readerinfo (reader_id, reader_name, reader_sex, reader_spec, reader_phone, reader_handing_time, reader_qianming, reader_image)
    VALUES (new.account, "", "", "", "", NOW(), "", "");
  END;
