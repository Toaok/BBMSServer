CREATE TRIGGER t_afterdelete_on_account
AFTER DELETE ON account
FOR EACH ROW
  BEGIN
    DELETE from readerinfo
    WHERE reader_id = OLD.account;
  END;
